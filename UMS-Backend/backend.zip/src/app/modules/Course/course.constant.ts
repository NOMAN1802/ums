export const CourseSearchableFields = ['title', 'prefix'];      
