export const USER_ROLE = {
  student: 'student',
  faculty: 'faculty',
  admin: 'admin',
} as const;

export const UserStatus = ['in-progress', 'blocked'];